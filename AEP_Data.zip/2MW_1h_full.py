"""
59_multiregion_2MW_1h_full.py

V80 2MW 风电场（Horns Rev 1 布局, 8×10, 560m）+ 8 海区 × 全年 × 1h
+ 防结冰（T_C >= 0 才喷雾）+ 俯视云图
================================================================
- 数据源：C:\\floris-4.2.1\\Nature-AEP-0922\\Place\\{region}-2025-70m_level.csv
- 8 个海区：asa_branca_i / bozhong / horns_rev_1 / plocan /
            red_bay / red_sea / south_fork_wind / taranto_beleolico
- 布局：HR1 实际布局（8 行 × 10 列，间距 560 m，7° 错列）
- 风机：V80 2MW，轮毂 70 m
- ★ 1h 分块 × 全年（8760 块/海区）
- ★ 上限喷雾流量 = 15 kg/s（能耗按 25→15 线性缩放）
- ★ 变流量缩放采用幂律：f_eff = f_tot^N_POWER（内部）
      tilt = tilt_a * f_eff
      vg   = vg_a   * f_eff
      we   = WE_BASE + f_eff * (WE_SPRAY - WE_BASE)
      E_pt = f_tot * E_UNIT_15      (能耗保持线性)
- 每个 1h 块：
    ① identify_spray_units(wd)：找被上游尾流影响的上游机组
    ② 触发条件：WS∈[6.5,12] 且 f_tot≥0.05 且 T_C ≥ 0（★ 防结冰）
    ③ 喷雾后净增益 > 0 才采用，否则退回 base
- Δu 云图 colorbar 固定 -1.0 ~ +1.0 m/s
- 输出目录（每个海区）：
      test\\results\\2MW_farm_N\\{region}_2MW_1h\\
          timeseries_results.csv
          monthly_summary.csv
          aep_summary.txt
          timeseries_analysis.png
          monthly_gain_series.png
          fig_representative_topview.png
- 全局汇总：
      test\\results\\2MW_farm_N\\_ALL_REGIONS_2MW_1h_summary.csv
"""
import os, math, time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from floris import FlorisModel
from floris.turbine_library.turbine_utilities import build_cosine_loss_turbine_dict

BASE      = r"C:\floris-4.2.1\Nature-AEP-0922\Place"
YAML_PATH = r"C:\floris-4.2.1\test-2025\emgauss.yaml"

# ★ 新输出目录
OUT_ROOT  = r"C:\floris-4.2.1\Nature-AEP-0922\test\results\2MW_farm_N"

REGIONS = [
    "asa_branca_i",
    "bozhong",
    "horns_rev_1",
    "plocan",
    "red_bay",
    "red_sea",
    "south_fork_wind",
    "taranto_beleolico",
]

TEST_MONTH  = None
BLOCK_HOURS = 1
T_MIN_SPRAY = 0.0

# ---------- Constants ----------
D = 80.0; hub_H = 70.0
TI_base = 0.0684

# ★ 上限流量 25 → 15 kg/s；能耗线性缩放
#    25 kg/s 时 = 66.1 kW，15 kg/s 时 = 66.1 × 15/25 = 39.66 kW
E_UNIT_25 = 66.1e3                                # 参考点：25 kg/s 时 66.1 kW
M_DOT_MAX = 15.0                                  # ★ 新上限 [kg/s]
E_UNIT_15 = E_UNIT_25 * (M_DOT_MAX / 25.0)        # = 39.66e3 W @ 15 kg/s
M_DOT_NOMINAL = 15.0                              # ★ 同步更新（原 25.0）

DEFLECTION_RATE = 7.0
WE_BASE = [0.023, 0.008]
WE_SPRAY = [0.046, 0.003]
WS_MIN = 6.5
WS_MAX = 12.0
F_MIN = 0.05

# 幂律指数（内部使用，不对外显示）
N_POWER = 1.40

# ---------- RHc curve ----------
T_TABLE   = np.array([0, 5, 10, 15, 20, 25, 26.85, 30, 35, 40, 45])
RHc_TABLE = np.array([42.2, 59.5, 71.2, 79.3, 84.9, 88.9, 90.0,
                      91.7, 93.7, 95.2, 96.3])

def rh_critical(T): return float(np.interp(T, T_TABLE, RHc_TABLE))
def f_humidity(T, RH):
    rhc = rh_critical(T)
    if RH <= rhc: return 1.0
    return float(np.clip((1.0-RH/100.0)/(1.0-rhc/100.0), 0.0, 1.0))

def get_tilt_vg_anchor(ws):
    if ws <= 8.0: return 20.0, 9.0
    if ws >= 10.0: return 8.0, 1.5
    frac = (ws - 8.0) / 2.0
    return 20.0 + frac*(8.0-20.0), 9.0 + frac*(1.5-9.0)

def f_optimal(ws):
    if ws <= 8.0: return 0.70
    if ws >= 10.0: return 1.00
    return 0.70 + (ws - 8.0) / 2.0 * 0.30

# ---------- V80 turbine ----------
v80_data = {
    "wind_speed": [4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25],
    "power": [58,149,277,461,696,985,1303,1607,1824,1939,1982,1994,1997,1999,
              2000,2000,2000,2000,2000,2000,2000,2000],
    "thrust_coefficient": [0.751,0.779,0.791,0.813,0.809,0.788,0.740,0.656,
                           0.539,0.392,0.308,0.247,0.203,0.169,0.143,0.122,
                           0.105,0.092,0.080,0.071,0.063,0.057],
}
v80_data["wind_speed"] = [0.0] + v80_data["wind_speed"] + [25.01, 50.0]
v80_data["power"] = [0.0] + v80_data["power"] + [0.0, 0.0]
v80_data["thrust_coefficient"] = [0.0] + v80_data["thrust_coefficient"] + [0.0, 0.0]

def make_turbine_def(tilt_deg, suffix=""):
    td = build_cosine_loss_turbine_dict(
        turbine_data_dict=v80_data, turbine_name=f"v80_2mw{suffix}",
        file_name=None, hub_height=hub_H, rotor_diameter=D, TSR=8.0,
        ref_tilt=tilt_deg)
    td["floating_tilt_table"] = {"wind_speed": [0.0, 50.0],
                                  "tilt": [tilt_deg, tilt_deg]}
    td["correct_cp_ct_for_tilt"] = False
    return td

# ---------- HR1 layout ----------
n_rows, n_cols = 8, 10
spacing = 560.0
tr = math.radians(7.0)
layout_x, layout_y = [], []
for i in range(n_rows):
    for j in range(n_cols):
        layout_x.append(j * spacing - i * spacing * math.sin(tr))
        layout_y.append(i * spacing * math.cos(tr))
layout_x = np.array(layout_x); layout_y = np.array(layout_y)
n_turbines = len(layout_x)

def identify_spray_units(wd_deg, R=D/2.0, k_wake=0.05):
    theta = math.radians(wd_deg)
    u_x = -math.sin(theta); u_y = -math.cos(theta)
    proj = layout_x * u_x + layout_y * u_y
    v_x = -u_y; v_y = u_x
    spray_units = []
    for i in range(n_turbines):
        for j in range(n_turbines):
            if i == j: continue
            dx = proj[j] - proj[i]
            if dx <= 0: continue
            dy = abs((layout_x[j]-layout_x[i])*v_x + (layout_y[j]-layout_y[i])*v_y)
            if dy < (R + k_wake*dx + R):
                spray_units.append(i); break
    return spray_units

def run_base(wd, ws):
    td = make_turbine_def(0.0, suffix="_base")
    fm = FlorisModel(YAML_PATH)
    fm.set(layout_x=layout_x.tolist(), layout_y=layout_y.tolist(),
           turbine_type=[td], reference_wind_height=hub_H,
           wind_directions=[wd], wind_speeds=[ws],
           turbulence_intensities=[TI_base])
    fm.run()
    return fm.get_turbine_powers()[0]

def run_spray(wd, ws, spray_units, tilt, vg, we):
    td = make_turbine_def(tilt, suffix="_spray")
    fm = FlorisModel(YAML_PATH)
    fm.set(layout_x=layout_x.tolist(), layout_y=layout_y.tolist(),
           turbine_type=[td], reference_wind_height=hub_H,
           wind_directions=[wd], wind_speeds=[ws],
           turbulence_intensities=[TI_base])
    fm.core.wake.velocity_model.wake_expansion_rates = list(we)
    fm.core.wake.deflection_model.vertical_deflection_gain_D = float(vg)
    fm.core.wake.deflection_model.deflection_rate = float(DEFLECTION_RATE)
    ta = np.zeros((1, n_turbines))
    for i in spray_units:
        ta[0, i] = tilt
    fm.core.farm.tilt_angles = ta.copy()
    fm.core.farm.tilt_angles_sorted = ta.copy()
    fm.run()
    return fm.get_turbine_powers()[0]

# ============================================================
# 单海区完整流程
# ============================================================
def run_region(region_name):
    print("\n" + "#" * 80)
    print(f"# Region: {region_name}   "
          f"[2MW HR1, 1h, T>={T_MIN_SPRAY}°C, full year, M_dot_max=15 kg/s]")
    print("#" * 80, flush=True)

    CSV_IN  = os.path.join(BASE, f"{region_name}-2025-70m_level.csv")
    OUT_DIR = os.path.join(OUT_ROOT, f"{region_name}_2MW_1h")
    os.makedirs(OUT_DIR, exist_ok=True)

    if not os.path.isfile(CSV_IN):
        print(f"  !!! FILE NOT FOUND: {CSV_IN}  —— skip region", flush=True)
        return None

    print(f"Reading: {CSV_IN}", flush=True)
    df = pd.read_csv(CSV_IN)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["T_C"] = df["temperature_K"] - 273.15
    df["RH"]  = df["relative_humidity_percent"].clip(0.0, 100.0)
    df["ws"]  = df["wind_speed_m_s"].clip(0.0, 30.0)
    if TEST_MONTH is not None:
        df = df[df["timestamp"].dt.month == TEST_MONTH].copy()
    df["block_start"] = df["timestamp"].dt.floor(f"{BLOCK_HOURS}h")

    def circ_mean_deg(a):
        rad = np.deg2rad(a.values)
        return float(np.rad2deg(np.arctan2(np.sin(rad).mean(),
                                            np.cos(rad).mean())) % 360.0)

    rows = []
    for block_start, sub in df.groupby("block_start"):
        rows.append({
            "t_start": block_start,
            "ws": float(sub["ws"].mean()),
            "wd": circ_mean_deg(sub["wind_direction_deg"]),
            "T_C": float(sub["T_C"].mean()),
            "RH":  float(sub["RH"].mean()),
        })
    cases = pd.DataFrame(rows).sort_values("t_start").reset_index(drop=True)
    print(f"  month={TEST_MONTH}, n blocks ({BLOCK_HOURS}h) = {len(cases)}\n",
          flush=True)

    print(f"Running {len(cases)} blocks "
          f"(T>={T_MIN_SPRAY}°C, frozen skip enabled) ...", flush=True)
    t0 = time.time()
    results = []

    n_trig_blocks = 0
    n_frozen_blocks = 0
    n_spray_calls = 0

    for k, row in cases.iterrows():
        wd, ws = float(row["wd"]), float(row["ws"])
        T_C, RH = float(row["T_C"]), float(row["RH"])

        P_base = run_base(wd, ws).sum()

        tilt_a, vg_a = get_tilt_vg_anchor(ws)
        f_opt = f_optimal(ws)
        f_hum = f_humidity(T_C, RH)
        f_tot = min(f_opt, f_hum)

        spray_units = identify_spray_units(wd)
        n_sp = len(spray_units)

        trigger_no_T = (n_sp > 0 and WS_MIN <= ws <= WS_MAX
                        and f_tot >= F_MIN)
        frozen_skip = trigger_no_T and (T_C < T_MIN_SPRAY)
        trigger = trigger_no_T and (T_C >= T_MIN_SPRAY)

        if trigger:
            n_trig_blocks += 1
            # ★ 幂律缩放（tilt / vg / we），能耗保持线性（基于新上限 15 kg/s）
            f_eff = f_tot ** N_POWER
            tilt = tilt_a * f_eff
            vg   = vg_a   * f_eff
            we1  = WE_BASE[0] + f_eff * (WE_SPRAY[0] - WE_BASE[0])
            we2  = WE_BASE[1] + f_eff * (WE_SPRAY[1] - WE_BASE[1])
            E_pt = f_tot * E_UNIT_15          # ★ 用 15 kg/s 对应能耗
            E_actual = E_pt * n_sp
            P_spray = run_spray(wd, ws, spray_units, tilt, vg, [we1, we2]).sum()
            n_spray_calls += 1
            P_net_test = P_spray - E_actual
            if P_net_test > P_base:
                P_net = P_net_test
                sprayed = n_sp
            else:
                P_net = P_base
                sprayed = 0
                E_actual = 0.0
        else:
            P_net = P_base
            sprayed = 0
            E_actual = 0.0
            if frozen_skip:
                n_frozen_blocks += 1

        gain = (P_net - P_base) / P_base * 100.0 if P_base > 1e5 else 0.0

        results.append({
            "t_start": row["t_start"],
            "ws": ws, "wd": wd, "T_C": T_C, "RH": RH,
            "f_opt": f_opt, "f_hum": f_hum, "f_tot": f_tot,
            "trigger": bool(trigger),
            "frozen_skip": bool(frozen_skip),
            "n_spray_avail": n_sp, "n_spray_active": sprayed,
            "E_total_kW": E_actual/1e3,
            "P_base_MW": P_base/1e6, "P_net_MW": P_net/1e6,
            "gain_pct": gain,
        })

        if (k+1) % 500 == 0:
            elapsed = time.time() - t0
            eta = elapsed / (k+1) * (len(cases) - k - 1)
            print(f"  {k+1}/{len(cases)}  elapsed={elapsed:.0f}s  ETA={eta:.0f}s",
                  flush=True)

    print(f"Done in {time.time()-t0:.0f}s\n", flush=True)

    # ---------- 诊断 ----------
    print("=" * 76)
    print(f"[诊断] run_spray calls      = {n_spray_calls}")
    print(f"[诊断] trigger blocks       = {n_trig_blocks}")
    print(f"[诊断] frozen blocks (T<0)  = {n_frozen_blocks}")
    print(f"[诊断] calls / trigger      = "
          f"{n_spray_calls/n_trig_blocks if n_trig_blocks else 0.0:.3f}")
    print("=" * 76)

    res = pd.DataFrame(results)
    res.to_csv(os.path.join(OUT_DIR, "timeseries_results.csv"), index=False)

    # ---------- AEP 汇总 ----------
    hours_total  = len(res) * BLOCK_HOURS
    AEP_base     = res["P_base_MW"].sum() * BLOCK_HOURS
    AEP_net      = res["P_net_MW"].sum()  * BLOCK_HOURS
    gain_pct     = (AEP_net - AEP_base) / AEP_base * 100
    hrs_spray    = (res["n_spray_active"] > 0).sum() * BLOCK_HOURS
    hrs_trigger  = int(res["trigger"].sum()) * BLOCK_HOURS
    hrs_frozen   = int(res["frozen_skip"].sum()) * BLOCK_HOURS
    E_total_kWh  = res["E_total_kW"].sum() * BLOCK_HOURS
    installed_MW = n_turbines * 2.0
    CF = AEP_base / (installed_MW * hours_total) * 100

    print("=" * 78)
    print(f"{region_name} — 2MW HR1, {BLOCK_HOURS}h blocks, "
          f"T>={T_MIN_SPRAY}°C, full year, M_dot_max=15 kg/s")
    print("=" * 78)
    print(f"  Cases                    : {len(res)}")
    print(f"  Total hours              : {hours_total}")
    print(f"  Trigger hours (all)      : {hrs_trigger} "
          f"({hrs_trigger/hours_total*100:.2f}%)")
    print(f"    - Frozen skipped (T<0) : {hrs_frozen} "
          f"({hrs_frozen/hours_total*100:.2f}%)")
    print(f"  Hours spraying           : {hrs_spray} "
          f"({hrs_spray/hours_total*100:.2f}%)")
    print(f"  AEP base                 : {AEP_base:,.0f} MWh")
    print(f"  AEP with spray           : {AEP_net:,.0f} MWh")
    print(f"  AEP net gain             : {gain_pct:+.3f}%")
    print(f"  Spray energy             : {E_total_kWh:,.0f} kWh  "
          f"({E_total_kWh/AEP_net/1000*100:.3f}% of AEP)")
    print(f"  Capacity factor          : {CF:.2f}% (base)")
    print("=" * 78)

    with open(os.path.join(OUT_DIR, "aep_summary.txt"),
              "w", encoding="utf-8") as f:
        f.write(f"{region_name} AEP - 2025 full year ({BLOCK_HOURS}h blocks)\n")
        f.write(f"M_dot_max = 15 kg/s (was 25)\n")
        f.write("=" * 60 + "\n")
        f.write(f"Cases              : {len(res)}\n")
        f.write(f"Block length (h)   : {BLOCK_HOURS}\n")
        f.write(f"Total hours        : {hours_total}\n")
        f.write(f"Trigger hours      : {hrs_trigger}\n")
        f.write(f"Frozen skipped (h) : {hrs_frozen}  [T < 0]\n")
        f.write(f"Hours spraying     : {hrs_spray} "
                f"({hrs_spray/hours_total*100:.2f}%)\n")
        f.write(f"AEP base           : {AEP_base:,.0f} MWh\n")
        f.write(f"AEP with spray     : {AEP_net:,.0f} MWh\n")
        f.write(f"AEP net gain       : {gain_pct:+.3f}%\n")
        f.write(f"Spray energy       : {E_total_kWh:,.0f} kWh\n")

    # ---------- 图 1 ----------
    active = res[res["n_spray_active"] > 0].copy()
    print(f"\nActive spray cases: {len(active)} / {len(res)} "
          f"({len(active)/len(res)*100:.1f}%)")

    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    ax = axes[0, 0]
    ax.hist(res["ws"], bins=50, color="steelblue", edgecolor="k", linewidth=0.3)
    ax.set_xlabel("WS (m/s)"); ax.set_ylabel("Count")
    ax.set_title("Wind speed distribution (all cases)")
    ax.grid(alpha=0.3)

    ax = axes[0, 1]
    ax.hist(active["gain_pct"], bins=60, color="crimson",
            edgecolor="k", linewidth=0.3)
    ax.axvline(0, color="k", lw=0.8)
    mean_active = active["gain_pct"].mean() if len(active) > 0 else 0.0
    ax.set_xlabel("Per-block net gain (%)"); ax.set_ylabel("Count")
    ax.set_title(f"Gain distribution (only spraying)\n"
                 f"n = {len(active)},  mean = {mean_active:+.2f}%")
    ax.grid(alpha=0.3)

    ax = axes[1, 0]
    if len(active) > 0:
        sc = ax.scatter(active["ws"], active["gain_pct"],
                        s=3, alpha=0.4, c=active["f_tot"],
                        cmap="viridis", vmin=0.4, vmax=1.0)
        plt.colorbar(sc, ax=ax, label="f_total")
    ax.axhline(0, color="k", lw=0.6)
    ax.set_xlabel("WS (m/s)"); ax.set_ylabel("Net gain (%)")
    ax.set_title("Gain vs wind speed (colored by f_total)")
    ax.grid(alpha=0.3)

    ax = axes[1, 1]
    if len(active) > 0:
        sc = ax.scatter(active["T_C"], active["RH"], c=active["f_tot"],
                        cmap="viridis", s=3, vmin=0, vmax=1)
        plt.colorbar(sc, ax=ax)
    ax.axvline(T_MIN_SPRAY, color="blue", ls="--", lw=1.2, alpha=0.7,
               label=f"T_min = {T_MIN_SPRAY}°C")
    ax.set_xlabel("T (°C)"); ax.set_ylabel("RH (%)")
    ax.set_title("Modulation factor f_total (only active cases)")
    ax.legend(fontsize=9); ax.grid(alpha=0.3)

    plt.suptitle(f"{region_name} — 2MW HR1, 2025 full-year AEP "
                 f"(overall net gain = {gain_pct:+.3f}%, "
                 f"$\\dot{{m}}_{{max}}$=15 kg/s)",
                 fontsize=13, y=0.995)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "timeseries_analysis.png"),
                dpi=140, bbox_inches="tight")
    plt.close()

    # ---------- 月度 ----------
    res["month"] = pd.to_datetime(res["t_start"]).dt.month
    monthly = res.groupby("month").apply(
        lambda g: pd.Series({
            "AEP_base_MWh": (g["P_base_MW"] * BLOCK_HOURS).sum(),
            "AEP_net_MWh":  (g["P_net_MW"]  * BLOCK_HOURS).sum(),
            "E_kWh":        (g["E_total_kW"] * BLOCK_HOURS).sum(),
            "spray_h":      int((g["n_spray_active"] > 0).sum()) * BLOCK_HOURS,
            "trigger_h":    int(g["trigger"].sum()) * BLOCK_HOURS,
            "frozen_h":     int(g["frozen_skip"].sum()) * BLOCK_HOURS,
        }), include_groups=False).reset_index()
    monthly["gain_pct"] = ((monthly["AEP_net_MWh"] - monthly["AEP_base_MWh"])
                           / monthly["AEP_base_MWh"] * 100)
    monthly["skip_h"] = monthly["trigger_h"] - monthly["spray_h"]
    monthly.to_csv(os.path.join(OUT_DIR, "monthly_summary.csv"), index=False)

    month_labels = ["Jan","Feb","Mar","Apr","May","Jun",
                    "Jul","Aug","Sep","Oct","Nov","Dec"]

    print("\nMonthly summary:")
    print(f"{'month':>6} {'gain%':>10} {'spray_h':>10} {'skip_h':>10} "
          f"{'frozen_h':>10}")
    for _, r in monthly.iterrows():
        m_idx = int(r["month"]) - 1
        print(f"{month_labels[m_idx]:>6} {r['gain_pct']:>+10.3f} "
              f"{int(r['spray_h']):>10d} {int(r['skip_h']):>10d} "
              f"{int(r['frozen_h']):>10d}")

    # ---------- 图 2 ----------
    fig, axes = plt.subplots(2, 1, figsize=(12, 8), sharex=True)
    ax = axes[0]
    ax.plot(monthly["month"], monthly["gain_pct"], 'o-',
            color="crimson", markersize=9, linewidth=2,
            markeredgecolor="k", markeredgewidth=0.6)
    for _, r in monthly.iterrows():
        ax.text(r["month"], r["gain_pct"] + 0.08,
                f"{r['gain_pct']:+.2f}%", ha="center", va="bottom",
                fontsize=9)
    ax.axhline(0, color="k", lw=0.6)
    ax.axhline(gain_pct, color="gray", ls=":", lw=1.0,
               label=f"annual mean = {gain_pct:+.3f}%")
    ax.set_ylabel("AEP net gain (%)", fontsize=12)
    ax.set_title(f"{region_name} — 2MW HR1, 2025 monthly AEP gain "
                 f"($\\dot{{m}}_{{max}}$=15 kg/s)",
                 fontsize=13)
    ax.set_xticks(range(1, 13)); ax.set_xticklabels(month_labels)
    ax.grid(alpha=0.3); ax.legend(fontsize=10)

    ax = axes[1]
    w = 0.6
    ax.bar(monthly["month"], monthly["spray_h"], w,
           color="steelblue", edgecolor="k", linewidth=0.5,
           label="Actually spraying")
    ax.bar(monthly["month"], monthly["skip_h"], w,
           bottom=monthly["spray_h"],
           color="lightcoral", edgecolor="k", linewidth=0.5,
           label="Skipped (net < 0)")
    ax.bar(monthly["month"], monthly["frozen_h"], w,
           bottom=monthly["spray_h"] + monthly["skip_h"],
           color="lightcyan", edgecolor="k", linewidth=0.5,
           label="Frozen skipped (T < 0°C)")
    ax.set_xlabel("Month", fontsize=12)
    ax.set_ylabel("Hours", fontsize=12)
    ax.set_title("Monthly hours: spray / net<0 skip / frozen skip", fontsize=13)
    ax.set_xticks(range(1, 13)); ax.set_xticklabels(month_labels)
    ax.grid(alpha=0.3, axis="y"); ax.legend(fontsize=10)

    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "monthly_gain_series.png"),
                dpi=140, bbox_inches="tight")
    plt.close()

    # ---------- 图 3：俯视云图 ----------
    if len(active) == 0:
        print("No spraying block — skip representative figure")
    else:
        active2 = active.copy()
        active2["dist_to_mean"] = np.abs(active2["gain_pct"] - mean_active)
        rep = active2.loc[active2["dist_to_mean"].idxmin()]

        rep_wd   = float(rep["wd"]); rep_ws = float(rep["ws"])
        rep_T    = float(rep["T_C"]); rep_RH = float(rep["RH"])
        rep_f    = float(rep["f_tot"])
        rep_feff = rep_f ** N_POWER
        rep_gain = float(rep["gain_pct"])
        rep_n_sp = int(rep["n_spray_active"])

        rep_spray_units = identify_spray_units(rep_wd)
        upstream_idx = set(rep_spray_units)

        tilt_a, vg_a = get_tilt_vg_anchor(rep_ws)
        rep_tilt = tilt_a * rep_feff
        rep_vg   = vg_a   * rep_feff

        print(f"\nRepresentative block:")
        print(f"  WD = {rep_wd:.1f}°, WS = {rep_ws:.2f} m/s")
        print(f"  T = {rep_T:.1f}°C, RH = {rep_RH:.1f}%")
        print(f"  f_tot = {rep_f:.3f}")
        print(f"  tilt = {rep_tilt:.2f}°, vg = {rep_vg:.2f}")
        print(f"  n_spray = {rep_n_sp}, gain = {rep_gain:+.3f}%")
        print(f"  spray_units (first 10) = {sorted(upstream_idx)[:10]}")

        WS_CT_TAB = np.array([5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
        CT_TAB    = np.array([0.779, 0.791, 0.813, 0.809, 0.788, 0.740,
                              0.656, 0.539, 0.392, 0.308, 0.247])

        def wake_deficit_peak(u_free):
            if u_free <= 0: return 0.0
            ct = np.interp(u_free, WS_CT_TAB, CT_TAB)
            if ct <= 0 or ct >= 1: return 0.0
            return u_free * (1.0 - np.sqrt(1.0 - ct)) / 2.0

        PAD = 500.0
        X_MIN = float(layout_x.min()) - PAD
        X_MAX = float(layout_x.max()) + PAD
        Y_MIN = float(layout_y.min()) - PAD
        Y_MAX = float(layout_y.max()) + PAD
        NX, NY = 700, 700

        def build_xy_field(ws, tilt_deg, vg, wd_deg, spray_units_set):
            theta = math.radians(wd_deg)
            ux = -math.sin(theta); uy = -math.cos(theta)
            x_grid = np.linspace(X_MIN, X_MAX, NX)
            y_grid = np.linspace(Y_MIN, Y_MAX, NY)
            X, Y = np.meshgrid(x_grid, y_grid)
            U = np.full_like(X, ws)

            d_peak = wake_deficit_peak(ws)
            if d_peak <= 0:
                return X, Y, U

            if tilt_deg > 0 and vg > 0:
                dz_asy = vg * D * math.sin(math.radians(tilt_deg))
                dz_asy = min(dz_asy, hub_H + 30.0)
            else:
                dz_asy = 0.0

            for i in range(n_turbines):
                xi, yi = layout_x[i], layout_y[i]
                dx = (X - xi) * ux + (Y - yi) * uy
                dy = -(X - xi) * uy + (Y - yi) * ux
                mask = dx > 0

                if (i in spray_units_set) and (dz_asy > 0):
                    zc = hub_H - dz_asy * (1.0 - np.exp(
                        -DEFLECTION_RATE * dx / D))
                else:
                    zc = hub_H

                sigma = D / 4.0 + 0.05 * dx
                g_y = np.exp(-(dy / sigma) ** 2)
                g_z = np.exp(-((hub_H - zc) / sigma) ** 2)
                decay = np.exp(-dx / (10.0 * D))
                U -= d_peak * g_y * g_z * decay * mask

            U = np.clip(U, 0.0, None)
            return X, Y, U

        X, Y, U_base  = build_xy_field(rep_ws, 0.0, 0.0, rep_wd, set())
        _, _, U_spray = build_xy_field(rep_ws, rep_tilt, rep_vg,
                                        rep_wd, upstream_idx)
        dU = U_spray - U_base

        vmin_u = float(min(np.nanmin(U_base), np.nanmin(U_spray)))
        vmax_u = float(max(np.nanmax(U_base), np.nanmax(U_spray)))
        if (not np.isfinite(vmin_u) or not np.isfinite(vmax_u)
                or vmax_u <= vmin_u):
            vmin_u, vmax_u = 0.0, 1.0
        levels_u = np.unique(np.linspace(vmin_u, vmax_u, 11))
        if len(levels_u) < 2:
            levels_u = np.array([vmin_u, vmin_u + 0.01])

        DU_FIXED  = 1.0
        levels_du = np.linspace(-DU_FIXED, DU_FIXED, 11)

        def draw_layout_xy(ax):
            for i in range(n_turbines):
                c  = "red"   if i in upstream_idx else "black"
                ms = 9       if i in upstream_idx else 4
                ax.plot(layout_x[i], layout_y[i], "o",
                        color=c, markersize=ms,
                        markeredgecolor="white", markeredgewidth=0.7,
                        zorder=10)
            theta = math.radians(rep_wd)
            ux = -math.sin(theta); uy = -math.cos(theta)
            L = 800.0
            xc = (X_MIN + X_MAX) / 2
            yc = Y_MAX - 400
            ax.annotate("", xy=(xc + ux*L, yc + uy*L),
                        xytext=(xc, yc),
                        arrowprops=dict(arrowstyle="-|>", color="black",
                                        lw=2.5, mutation_scale=20),
                        zorder=15)
            ax.text(xc - ux*L*0.6, yc - uy*L*0.6, "WD",
                    fontsize=11, fontweight="bold",
                    ha="center", va="center", zorder=15)

        fig, axes = plt.subplots(1, 3, figsize=(22, 8))

        ax = axes[0]
        cf = ax.pcolormesh(X, Y, U_base, cmap="RdBu_r",
                           vmin=vmin_u, vmax=vmax_u,
                           shading="auto", rasterized=True)
        ax.contour(X, Y, U_base, levels=levels_u, colors="gray",
                   linewidths=0.4, alpha=0.4)
        draw_layout_xy(ax)
        ax.set_xlim(X_MIN, X_MAX); ax.set_ylim(Y_MIN, Y_MAX)
        ax.set_aspect("equal")
        ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)")
        ax.set_title(f"(a) No spray  (z={hub_H:.0f} m)   "
                     f"WD={rep_wd:.0f}°, WS={rep_ws:.1f} m/s", fontsize=11)
        plt.colorbar(cf, ax=ax, label="$u$ (m/s)", shrink=0.85)

        ax = axes[1]
        cf = ax.pcolormesh(X, Y, U_spray, cmap="RdBu_r",
                           vmin=vmin_u, vmax=vmax_u,
                           shading="auto", rasterized=True)
        ax.contour(X, Y, U_spray, levels=levels_u, colors="gray",
                   linewidths=0.4, alpha=0.4)
        draw_layout_xy(ax)
        ax.set_xlim(X_MIN, X_MAX); ax.set_ylim(Y_MIN, Y_MAX)
        ax.set_aspect("equal")
        ax.set_xlabel("x (m)")
        ax.set_title(f"(b) Spray (n={len(upstream_idx)})   "
                     f"tilt={rep_tilt:.1f}°, vg={rep_vg:.2f}   "
                     f"gain={rep_gain:+.2f}%", fontsize=11)
        plt.colorbar(cf, ax=ax, label="$u$ (m/s)", shrink=0.85)

        ax = axes[2]
        cf = ax.pcolormesh(X, Y, dU, cmap="RdBu_r",
                           vmin=-DU_FIXED, vmax=DU_FIXED,
                           shading="auto", rasterized=True)
        ax.contour(X, Y, dU, levels=levels_du, colors="gray",
                   linewidths=0.4, alpha=0.4)
        draw_layout_xy(ax)
        ax.set_xlim(X_MIN, X_MAX); ax.set_ylim(Y_MIN, Y_MAX)
        ax.set_aspect("equal")
        ax.set_xlabel("x (m)")
        ax.set_title(r"(c) $\Delta u$ = Spray $-$ No spray  "
                     r"(fixed $\pm 1.0$ m/s)", fontsize=11)
        plt.colorbar(cf, ax=ax, label=r"$\Delta u$ (m/s)",
                     shrink=0.85, extend="both")

        plt.suptitle(
            f"{region_name} — V80 2MW HR1 (8×10, 560m, 7° stagger) "
            f"hub-height top view (z={hub_H:.0f} m)  |  "
            f"rep block: WD={rep_wd:.0f}°, WS={rep_ws:.2f} m/s, "
            f"T={rep_T:.1f}°C, RH={rep_RH:.1f}%, "
            f"n_spray={len(upstream_idx)}, gain={rep_gain:+.2f}%",
            fontsize=12, y=0.995)
        plt.tight_layout(rect=[0, 0, 1, 0.97])
        plt.savefig(os.path.join(OUT_DIR, "fig_representative_topview.png"),
                    dpi=140, bbox_inches="tight")
        plt.close()

    print(f"\nOutputs -> {OUT_DIR}")

    return {
        "region": region_name,
        "block_h": BLOCK_HOURS,
        "M_dot_max": M_DOT_MAX,
        "n_turbines": n_turbines,
        "n_blocks": len(res),
        "total_h": hours_total,
        "trigger_h": hrs_trigger,
        "frozen_h": hrs_frozen,
        "spray_h": hrs_spray,
        "AEP_base_MWh": AEP_base,
        "AEP_net_MWh":  AEP_net,
        "net_gain_pct": gain_pct,
        "E_total_kWh":  E_total_kWh,
        "CF_pct": CF,
        "run_spray_calls": n_spray_calls,
    }

# ============================================================
# 主程序
# ============================================================
if __name__ == "__main__":
    os.makedirs(OUT_ROOT, exist_ok=True)
    t_all = time.time()
    summary_rows = []
    for region in REGIONS:
        try:
            r = run_region(region)
            if r is not None:
                summary_rows.append(r)
        except Exception as e:
            print(f"\n!!! Region {region} failed: {e}", flush=True)

    if summary_rows:
        summ = pd.DataFrame(summary_rows)
        summ_path = os.path.join(OUT_ROOT, "_ALL_REGIONS_2MW_1h_summary.csv")
        summ.to_csv(summ_path, index=False)
        print("\n" + "=" * 90)
        print(f"ALL REGIONS — 2MW HR1, 1h, T>=0°C, full year, M_dot_max=15 kg/s")
        print("=" * 90)
        with pd.option_context("display.width", 220,
                                "display.max_columns", 50):
            print(summ.to_string(index=False))
        print("=" * 90)
        print(f"Summary -> {summ_path}")

    print(f"\nTotal wall time: {(time.time()-t_all)/60:.1f} min")
    print("All regions done.")