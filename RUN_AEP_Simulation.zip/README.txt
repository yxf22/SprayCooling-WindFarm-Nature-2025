Supplementary Data
=================

This archive contains the numerical data and the simulation code
underlying the manuscript and its Supplementary Information.

Packaged on : 2026-10-21


Directory layout
----------------

AEP_Data/
  README.txt                          (this file)
  requirements.txt                    Python dependencies (floris==4.2.1, numpy, pandas, matplotlib, scipy)
  emgauss.yaml                        FLORIS wake model configuration file

  _ALL_REGIONS_2MW_1h_summary.csv     Annual summary, 2 MW farm, all 8 regions
  _ALL_REGIONS_15MW_1h_summary.csv    Annual summary, 15 MW farm, all 8 regions

  2MW_1h_full.py                      FLORIS driver, V80 2 MW, Horns Rev 1 layout
  15MW_6x6_1h_full.py                 FLORIS driver, IEA 15 MW, 6x6 @ 7D layout

  Place/                              Input meteorology (8 regions x 2 hub heights)
  results/                            Output directory (auto-generated)


Installation and Execution
--------------------------

1. Install dependencies:
   pip install -r requirements.txt

2. Run the 2 MW farm simulation (all 8 regions):
   python 2MW_1h_full.py

3. Run the 15 MW farm simulation (all 8 regions):
   python 15MW_6x6_1h_full.py

Note: The scripts automatically locate the 'Place' folder and 'emgauss.yaml' 
in the current directory, and write outputs to the 'results' folder.


Contents
--------

Top-level summary tables
    _ALL_REGIONS_2MW_1h_summary.csv
        One row per sea region.  Annual AEP (base / net), net gain (%),
        spray hours, trigger hours, frozen-skip hours, spray energy,
        capacity factor, etc.  (V80 2 MW, HR1 layout.)
    _ALL_REGIONS_15MW_1h_summary.csv
        One row per sea region.  Same columns as above for the IEA
        15 MW 6x6 @ 7D farm.

results/2MW_farm/
    {region}_2MW_1h/
        timeseries_results.csv       Hourly time series (8760 h)
        monthly_summary.csv          Monthly aggregates
        aep_summary.txt              Summary of AEP and energy consumption
        timeseries_analysis.png      Histograms of wind speed and net gain
        monthly_gain_series.png      Monthly variation of AEP gain
        fig_representative_topview.png  Flow visualization (No-spray vs Spray vs Difference)

results/15MW_farm/
    {region}_6x6_1h_adaptive/
        timeseries_1h.csv            Hourly time series (8760 h)
        monthly_summary.csv          Monthly aggregates
        fig_monthly.png              Monthly variation of AEP gain
        fig_4panel.png               Analysis of spray triggers and distributions
        fig_representative_topview.png  Flow visualization of the 6x6 array

Place/
    {region}-2025-70m_level.csv      Input meteorology at 70 m hub (2 MW farm)
    {region}-2025-150m_level.csv     Input meteorology at 150 m hub (15 MW farm)


Sea-region nomenclature (matches Table S2 of the paper)
-------------------------------------------------------

The internal folder names use the original site identifiers; in the
manuscript each site is referred to by the abbreviation of its sea
region.  The mapping is:

  Folder name (this archive)    Abbr.   Sea region (EN)
  ----------------------------  ------  --------------------------------
  asa_branca_i                  EA      Equatorial Atlantic
  bozhong                       BS      Bohai Sea
  horns_rev_1                   NS      North Sea
  plocan                        ENA     Eastern North Atlantic
  red_bay                       SCS     South China Sea
  red_sea                       RS      Red Sea
  south_fork_wind               NA      Northwest Atlantic
  taranto_beleolico             MS      Mediterranean Sea

Table S2 of the manuscript (Sea-region abbreviations):

  Abbreviation  Site name                 
  ------------  ------------------------  
  NA            Northwest Atlantic        
  EA            Equatorial Atlantic       
  ENA           Eastern North Atlantic    
  NS            North Sea                 
  MS            Mediterranean Sea         
  RS            Red Sea                   
  SCS           South China Sea           
  BS            Bohai Sea                 


Simulation setup
----------------

All simulations were performed with FLORIS (v4.2.1) coupled to the
emgauss wake model.

  2MW_1h_full.py
      V80 2 MW turbine on the Horns Rev 1 layout (8 x 10, 560 m
      spacing, 7-deg stagger).  Hourly (1 h) blocks for the full
      year 2025.  Ice protection: spray only when T >= 0 degC.
      Spray flow capped at 15 kg/s.
      Reads  : Place/{region}-2025-70m_level.csv
      Writes : results/2MW_farm/{region}_2MW_1h/

  15MW_6x6_1h_full.py
      IEA 15 MW turbine on a regular 6 x 6 array with 7D spacing.
      Hourly (1 h) blocks for the full year 2025.  Greedy
      unit-by-unit spray selection (up to 6 spraying units per
      time step).
      Reads  : Place/{region}-2025-150m_level.csv
      Writes : results/15MW_farm/{region}_6x6_1h_adaptive/


Data files
----------

2MW farm (V80 2 MW, Horns Rev 1 layout, 80 turbines):

  timeseries_results.csv
      One row per hourly block (8760 rows).  Columns:
        t_start, ws, wd, T_C, RH,
        f_opt, f_hum, f_tot,
        trigger, frozen_skip,
        n_spray_avail, n_spray_active,
        E_total_kW, P_base_MW, P_net_MW, gain_pct.

  monthly_summary.csv
      One row per month.  Columns:
        month, AEP_base_MWh, AEP_net_MWh, E_kWh,
        spray_h, trigger_h, frozen_h, gain_pct, skip_h.

15MW farm (IEA 15 MW, 6 x 6 array at 7D spacing, 36 turbines):

  timeseries_1h.csv
      One row per hourly block (8760 rows).  Columns:
        t_start, ws, wd, T_C, RH,
        E_max, m_evap, f_evap,
        trigger, frozen_skip, use_spray,
        n_candidates, n_spray, spray_units,
        tilt, we0, vg,
        E_total_kW, P_base_MW, P_net_MW, gross_pct, gain_pct.

  monthly_summary.csv
      One row per month.  Columns:
        month, AEP_base_MWh, AEP_net_MWh, E_kWh,
        spray_h, trigger_h, frozen_h, gain_pct, skip_h.

Input meteorology (Place/)
--------------------------

Hourly reanalysis fields for the year 2025 at each of the 8 sea
regions, interpolated to the turbine hub height (70 m for the V80
2 MW turbine, 150 m for the IEA 15 MW turbine).  Columns:

  timestamp
  wind_speed_m_s
  wind_direction_deg
  temperature_K
  relative_humidity_percent


Contact
-------

  Corresponding author: Shengli Chen
  Email:                shenglichen@sz.tsinghua.edu.cn