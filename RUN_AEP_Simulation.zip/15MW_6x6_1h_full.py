"""
15MW_6x6_1h_full.py

6x6 wind farm matrix (7D spacing) + Greedy unit-by-unit spray + 8 sea regions x full year x 1h
================================================================
- Layout: 6 rows x 6 cols, 7D spacing (36 IEA 15MW turbines in total)
- Data source: Place/{region}-2025-150m_level.csv
- 8 sea regions: asa_branca_i / bozhong / horns_rev_1 / plocan /
                red_bay / red_sea / south_fork_wind / taranto_beleolico
- ★ 1h blocks x full year (8760 blocks per region)
- For each 1h block:
    ① find_free_upstream_units(wd, max_n=6): Find "completely free" upstream units
    ② Greedy: Spray all candidates first, if net gain <= 0, remove the most downstream one, and recalculate
    ③ Max 6~7 spray FLORIS calls per triggered block
- Output directory (per region):
      results/15MW_farm/{region}_6x6_1h_adaptive/
================================================================
"""
import os, math, time, ast
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from floris import FlorisModel
from floris.turbine_library.turbine_utilities import build_cosine_loss_turbine_dict
from scipy.interpolate import griddata

# ============================================================
# Dynamic Paths (Fully portable)
# ============================================================
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE      = os.path.join(CURRENT_DIR, "Place")
YAML_PATH = os.path.join(CURRENT_DIR, "emgauss.yaml")
OUT_ROOT  = os.path.join(CURRENT_DIR, "results", "15MW_farm")

REGIONS = [
    "asa_branca_i", "bozhong", "horns_rev_1", "plocan",
    "red_bay", "red_sea", "south_fork_wind", "taranto_beleolico",
]

TEST_MONTH  = None         # Full year
BLOCK_HOURS = 1            # 1h blocks

# ---------- Geometry ----------
D, hub_H = 240.0, 150.0
N_ROW, N_COL = 6, 6
SPACING = 7.0 * D          # 7D standard spacing
N_TURB = N_ROW * N_COL

MAX_SPRAY = 6

# ---------- Constants (v2) ----------
TI_BASE, WIND_SHEAR = 0.0684, 0.14
DEFLECTION_RATE = 7.0
WE_BASE = [0.040, 0.008]
WE1_SPRAY = 0.003
TILT_CAP = 25.0
VG_CONST = 0.70

E_UNIT_REF_W = 94.6e3
E_UNIT_REF_M = 25.0

A_W, B_W, C_W, D_W = +0.098713, -0.007164, -0.107570, +0.013764
T_TABLE   = np.array([0,5,10,15,20,25,26.85,30,35,40,45])
RHc_TABLE = np.array([42.2,59.5,71.2,79.3,84.9,88.9,90.0,
                      91.7,93.7,95.2,96.3])
E_REF, WS_REF_E, ALPHA = 23.4, 8.0, 1.6
M_DOT_CAP = 50.0
WS_MIN, WS_MAX, M_EVAP_MIN = 5.0, 12.0, 5.0
T_MIN_SPRAY = 0.0

# ---------- Layout (6x6, 7D) ----------
layout_x, layout_y = [], []
for i in range(N_ROW):
    for j in range(N_COL):
        layout_x.append(j * SPACING)
        layout_y.append(i * SPACING)
layout_x = np.array(layout_x); layout_y = np.array(layout_y)

# ---------- Free upstream unit detection ----------
def find_free_upstream_units(wd_deg, max_n=MAX_SPRAY):
    theta = math.radians(wd_deg)
    ux = -math.sin(theta); uy = -math.cos(theta)
    vx = -math.cos(theta); vy =  math.sin(theta)
    s = layout_x * ux + layout_y * uy
    t = layout_x * vx + layout_y * vy

    free = []
    for i in range(N_TURB):
        in_wake = False
        for j in range(N_TURB):
            if i == j: continue
            dx = s[i] - s[j]
            if dx <= 0: continue
            if abs(t[i] - t[j]) < D / 4.0 + 0.05 * dx:
                in_wake = True
                break
        if not in_wake:
            free.append(i)
    free = sorted(free, key=lambda k: s[k])
    return free[:max_n]

# ---------- IEA 15MW Curve ----------
iea_15mw_data = {
    "wind_speed":[0.,3,4,5,6,7,8,9,10,10.59,11,12,13,14,15,16,17,18,19,
                  20,21,22,23,24,25,25.01,50],
    "power":[0.,500,1000,2000,3500,5500,8000,10500,13000,15000,15000,
             15000,15000,15000,15000,15000,15000,15000,15000,15000,
             15000,15000,15000,15000,15000,0,0],
    "thrust_coefficient":[0.,0.821,0.818,0.816,0.812,0.808,0.806,0.804,
                          0.804,0.806,0.807,0.765,0.697,0.633,0.575,
                          0.524,0.480,0.443,0.411,0.384,0.360,0.339,
                          0.320,0.303,0.288,0.288,0.],
}

# ---------- Physics ----------
def E_max(T_C, RH, WS):
    RHc = np.interp(T_C, T_TABLE, RHc_TABLE)
    frac = (1 - RH/100.0) / (1 - RHc/100.0)
    return max(0.0, E_REF * frac * (WS/WS_REF_E)**ALPHA)

def tilt_v2(m_evap):
    return 0.0 if m_evap <= 0 else min(TILT_CAP, 1.0 * m_evap)

def we0_from_fevap(ws, f):
    return A_W + B_W*ws + C_W*f + D_W*ws*f

def E_unit_var(m_evap):
    return E_UNIT_REF_W * (m_evap / E_UNIT_REF_M)

# ---------- FLORIS Wrapper ----------
def make_turbine_def(tilt_run, ref_tilt, suffix=""):
    td = build_cosine_loss_turbine_dict(
        turbine_data_dict=iea_15mw_data,
        turbine_name=f"iea15mw{suffix}",
        file_name=None, hub_height=hub_H, rotor_diameter=D,
        TSR=8.0, ref_tilt=ref_tilt)
    td["floating_tilt_table"] = {"wind_speed":[0.,50.],
                                  "tilt":[tilt_run, tilt_run]}
    td["correct_cp_ct_for_tilt"] = False
    return td

def run_base(wd, ws):
    td = make_turbine_def(0., 0., "_base")
    fm = FlorisModel(YAML_PATH)
    fm.set(layout_x=layout_x.tolist(), layout_y=layout_y.tolist(),
           turbine_type=[td], reference_wind_height=hub_H,
           wind_directions=[wd], wind_speeds=[ws],
           turbulence_intensities=[TI_BASE], wind_shear=WIND_SHEAR)
    fm.core.wake.velocity_model.wake_expansion_rates = WE_BASE
    fm.core.wake.deflection_model.vertical_deflection_gain_D = 0.0
    fm.core.wake.deflection_model.deflection_rate = float(DEFLECTION_RATE)
    ta = np.zeros((1, N_TURB))
    fm.core.farm.tilt_angles = ta.copy()
    fm.core.farm.tilt_angles_sorted = ta.copy()
    fm.run()
    return fm.get_turbine_powers()[0].copy()

def run_edge_spray(wd, ws, spray_units, tilt, vg, we0):
    spray_td = make_turbine_def(tilt, tilt, "_edespray")
    base_td  = make_turbine_def(0., 0., "_edgebase")
    tt = [base_td] * N_TURB
    for i in spray_units: tt[i] = spray_td
    fm = FlorisModel(YAML_PATH)
    fm.set(layout_x=layout_x.tolist(), layout_y=layout_y.tolist(),
           turbine_type=tt, reference_wind_height=hub_H,
           wind_directions=[wd], wind_speeds=[ws],
           turbulence_intensities=[TI_BASE], wind_shear=WIND_SHEAR)
    fm.core.wake.velocity_model.wake_expansion_rates = [we0, WE1_SPRAY]
    fm.core.wake.deflection_model.vertical_deflection_gain_D = float(vg)
    fm.core.wake.deflection_model.deflection_rate = float(DEFLECTION_RATE)
    ta = np.zeros((1, N_TURB))
    for i in spray_units: ta[0, i] = tilt
    fm.core.farm.tilt_angles = ta.copy()
    fm.core.farm.tilt_angles_sorted = ta.copy()
    fm.run()
    return fm.get_turbine_powers()[0].copy()

# ============================================================
# Full workflow for a single region
# ============================================================
def run_region(region_name):
    print("\n" + "#" * 80)
    print(f"# Region: {region_name}   "
          f"[6x6 @ 7D, 1h, GREEDY 1-{MAX_SPRAY} spray, full year]")
    print("#" * 80, flush=True)

    csv_file = f"{region_name}-2025-150m_level.csv"
    CSV_IN   = os.path.join(BASE, csv_file)
    OUT_DIR  = os.path.join(OUT_ROOT, f"{region_name}_6x6_1h_adaptive")
    os.makedirs(OUT_DIR, exist_ok=True)

    if not os.path.isfile(CSV_IN):
        print(f"  !!! FILE NOT FOUND: {CSV_IN}  -- skip region", flush=True)
        return None

    print(f"Reading: {CSV_IN}", flush=True)
    df = pd.read_csv(CSV_IN)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["T_C"] = df["temperature_K"] - 273.15
    df["RH"]  = df["relative_humidity_percent"].clip(0.0, 100.0)
    df["ws"]  = df["wind_speed_m_s"].clip(0.0, 40.0)
    if TEST_MONTH is not None:
        df = df[df["timestamp"].dt.month == TEST_MONTH].copy()
    df["block_start"] = df["timestamp"].dt.floor(f"{BLOCK_HOURS}h")

    def circ_mean_deg(a):
        rad = np.deg2rad(a.values)
        return float(np.rad2deg(np.arctan2(np.sin(rad).mean(),
                                            np.cos(rad).mean())) % 360.0)

    rows = []
    for block_start, sub in df.groupby("block_start"):
        rows.append({
            "t_start": block_start,
            "ws": float(sub["ws"].mean()),
            "wd": circ_mean_deg(sub["wind_direction_deg"]),
            "T_C": float(sub["T_C"].mean()),
            "RH":  float(sub["RH"].mean()),
        })
    cases = pd.DataFrame(rows).sort_values("t_start").reset_index(drop=True)
    print(f"  month={TEST_MONTH}, n blocks ({BLOCK_HOURS}h) = {len(cases)}\n",
          flush=True)

    print(f"Running {len(cases)} blocks "
          f"(GREEDY 1-{MAX_SPRAY} spray, T>={T_MIN_SPRAY}degC) ...", flush=True)
    t0 = time.time()
    results = []

    n_spray_calls = 0
    n_trig_blocks = 0
    cand_sum  = 0
    spray_sum = 0

    for k, row in cases.iterrows():
        wd, ws = float(row["wd"]), float(row["ws"])
        T_C, RH = float(row["T_C"]), float(row["RH"])

        P_base = run_base(wd, ws)
        P_base_tot = P_base.sum()

        E = E_max(T_C, RH, ws)
        m_evap = min(M_DOT_CAP, E)
        f_evap = m_evap / E if E > 1e-6 else 0.0

        trigger = (WS_MIN <= ws <= WS_MAX
                   and m_evap >= M_EVAP_MIN
                   and T_C >= T_MIN_SPRAY)
        trigger_no_T = (WS_MIN <= ws <= WS_MAX
                        and m_evap >= M_EVAP_MIN)
        frozen_skip = trigger_no_T and (T_C < T_MIN_SPRAY)

        if trigger:
            n_trig_blocks += 1
            tilt = tilt_v2(m_evap)
            we0  = max(WE_BASE[0], we0_from_fevap(ws, f_evap))
            vg   = VG_CONST

            candidates = find_free_upstream_units(wd, max_n=MAX_SPRAY)
            n_cand = len(candidates)
            cand_sum += n_cand

            E_unit_W = E_unit_var(m_evap)

            selected = list(candidates)
            best_sub       = None
            best_net       = -1e9
            best_P_gross   = 0.0
            best_E_total_W = 0.0

            while selected:
                P_spray = run_edge_spray(wd, ws, selected, tilt, vg, we0)
                n_spray_calls += 1
                P_spray_sum = P_spray.sum()
                E_total_W   = E_unit_W * len(selected)
                net_gain    = (P_spray_sum - E_total_W
                               - P_base_tot) / P_base_tot * 100.0
                if net_gain > 0:
                    best_sub       = tuple(selected)
                    best_net       = net_gain
                    best_P_gross   = P_spray_sum
                    best_E_total_W = E_total_W
                    break
                selected = selected[:-1]

            if best_sub is not None and best_net > 0:
                spray_sum += len(best_sub)
                gross_gain = (best_P_gross - P_base_tot) / P_base_tot * 100.0
                results.append({
                    "t_start": row["t_start"], "ws": ws, "wd": wd,
                    "T_C": T_C, "RH": RH,
                    "E_max": E, "m_evap": m_evap, "f_evap": f_evap,
                    "trigger": True, "frozen_skip": False,
                    "use_spray": True,
                    "n_candidates": n_cand,
                    "n_spray": len(best_sub),
                    "spray_units": str(best_sub),
                    "tilt": tilt, "we0": we0, "vg": vg,
                    "E_total_kW": best_E_total_W / 1e3,
                    "P_base_MW": P_base_tot / 1e6,
                    "P_net_MW":  (best_P_gross - best_E_total_W) / 1e6,
                    "gross_pct": gross_gain,
                    "gain_pct":  best_net,
                })
            else:
                results.append({
                    "t_start": row["t_start"], "ws": ws, "wd": wd,
                    "T_C": T_C, "RH": RH,
                    "E_max": E, "m_evap": m_evap, "f_evap": f_evap,
                    "trigger": True, "frozen_skip": False,
                    "use_spray": False,
                    "n_candidates": n_cand,
                    "n_spray": 0,
                    "spray_units": "()",
                    "tilt": 0.0, "we0": WE_BASE[0], "vg": 0.0,
                    "E_total_kW": 0.0,
                    "P_base_MW": P_base_tot / 1e6,
                    "P_net_MW":  P_base_tot / 1e6,
                    "gross_pct": 0.0, "gain_pct": 0.0,
                    "skip_net_pct": 0.0,
                })
        else:
            results.append({
                "t_start": row["t_start"], "ws": ws, "wd": wd,
                "T_C": T_C, "RH": RH,
                "E_max": E, "m_evap": m_evap, "f_evap": f_evap,
                "trigger": False, "frozen_skip": bool(frozen_skip),
                "use_spray": False,
                "n_candidates": 0,
                "n_spray": 0,
                "spray_units": "()",
                "tilt": 0.0, "we0": WE_BASE[0], "vg": 0.0,
                "E_total_kW": 0.0,
                "P_base_MW": P_base_tot / 1e6,
                "P_net_MW":  P_base_tot / 1e6,
                "gross_pct": 0.0, "gain_pct": 0.0,
            })

        if (k + 1) % 500 == 0:
            el = time.time() - t0
            eta = el / (k + 1) * (len(cases) - k - 1)
            print(f"  {k+1}/{len(cases)}  elapsed={el:.0f}s  ETA={eta:.0f}s",
                  flush=True)

    print(f"Done in {time.time()-t0:.0f}s\n", flush=True)

    avg_cand   = cand_sum  / n_trig_blocks if n_trig_blocks else 0.0
    avg_spray  = spray_sum / n_trig_blocks if n_trig_blocks else 0.0
    call_ratio = n_spray_calls / n_trig_blocks if n_trig_blocks else 0.0
    print("=" * 76)
    print(f"[Diagnostics] run_edge_spray calls = {n_spray_calls}")
    print(f"[Diagnostics] trigger blocks       = {n_trig_blocks}")
    print(f"[Diagnostics] calls / trigger      = {call_ratio:.3f}")
    print(f"[Diagnostics] avg n_candidates     = {avg_cand:.3f}")
    print(f"[Diagnostics] avg n_spray_units    = {avg_spray:.3f}")
    print("=" * 76)

    res = pd.DataFrame(results)
    res.to_csv(os.path.join(OUT_DIR, "timeseries_1h.csv"), index=False)

    AEP_base = (res["P_base_MW"] * BLOCK_HOURS).sum()
    AEP_net  = (res["P_net_MW"]  * BLOCK_HOURS).sum()
    E_total_kWh  = (res["E_total_kW"] * BLOCK_HOURS).sum()
    spray_hours   = int(res["use_spray"].sum()) * BLOCK_HOURS
    trigger_hours = int(res["trigger"].sum()) * BLOCK_HOURS
    frozen_hours  = int(res["frozen_skip"].sum()) * BLOCK_HOURS
    skip_hours    = trigger_hours - spray_hours
    total_hours   = len(res) * BLOCK_HOURS
    net_gain   = (AEP_net - AEP_base) / AEP_base * 100
    gross_gain = ((AEP_net + E_total_kWh/1e3) - AEP_base) / AEP_base * 100
    energy_pct = (E_total_kWh / 1e3) / AEP_base * 100
    installed_MW = N_TURB * 15.0
    CF = AEP_base / (installed_MW * total_hours) * 100

    print(f"{'='*76}")
    print(f"{region_name} -- {N_ROW}x{N_COL} @ 7D, 1h, GREEDY 1-{MAX_SPRAY} spray")
    print(f"{'='*76}")
    print(f"Block length (h)     : {BLOCK_HOURS}")
    print(f"Total hours          : {total_hours}")
    print(f"Trigger hours (all)  : {trigger_hours} "
          f"({trigger_hours/total_hours*100:.2f}%)")
    print(f"  - Frozen skipped   : {frozen_hours} "
          f"({frozen_hours/total_hours*100:.2f}%)  [T < 0]")
    print(f"  - Net<0 skipped    : {skip_hours} "
          f"({skip_hours/total_hours*100:.2f}%)")
    print(f"Actually spraying    : {spray_hours} "
          f"({spray_hours/total_hours*100:.2f}%)")
    print(f"AEP base             : {AEP_base:,.0f} MWh")
    print(f"AEP with spray       : {AEP_net:,.0f} MWh")
    print(f"AEP gross gain       : {gross_gain:+.3f}%")
    print(f"AEP net gain         : {net_gain:+.3f}%")
    print(f"Spray energy         : {E_total_kWh:,.0f} kWh  "
          f"({energy_pct:.3f}% of base)")
    print(f"Capacity factor      : {CF:.2f}% (base)")
    print("=" * 76)

    res["month"] = pd.to_datetime(res["t_start"]).dt.month
    monthly = res.groupby("month").apply(
        lambda g: pd.Series({
            "AEP_base_MWh": (g["P_base_MW"] * BLOCK_HOURS).sum(),
            "AEP_net_MWh":  (g["P_net_MW"]  * BLOCK_HOURS).sum(),
            "E_kWh":        (g["E_total_kW"] * BLOCK_HOURS).sum(),
            "spray_h":      int(g["use_spray"].sum()) * BLOCK_HOURS,
            "trigger_h":    int(g["trigger"].sum()) * BLOCK_HOURS,
            "frozen_h":     int(g["frozen_skip"].sum()) * BLOCK_HOURS,
        }), include_groups=False).reset_index()
    monthly["gain_pct"] = ((monthly["AEP_net_MWh"] - monthly["AEP_base_MWh"])
                           / monthly["AEP_base_MWh"] * 100)
    monthly["skip_h"] = monthly["trigger_h"] - monthly["spray_h"]
    monthly.to_csv(os.path.join(OUT_DIR, "monthly_summary.csv"), index=False)

    labels_m = ["Jan","Feb","Mar","Apr","May","Jun",
                "Jul","Aug","Sep","Oct","Nov","Dec"]
    print("\nMonthly net gain:")
    print(f"{'month':>6} {'gain%':>10} {'spray_h':>10} {'skip_h':>10} "
          f"{'frozen_h':>10}")
    for _, r in monthly.iterrows():
        m_idx = int(r["month"]) - 1
        print(f"{labels_m[m_idx]:>6} {r['gain_pct']:>+10.3f} "
              f"{int(r['spray_h']):>10d} {int(r['skip_h']):>10d} "
              f"{int(r['frozen_h']):>10d}")

    # ---------- Figure 1 ----------
    fig, axes = plt.subplots(2, 1, figsize=(14, 10), sharex=True)
    ax = axes[0]
    ax.plot(monthly["month"], monthly["gain_pct"], "o-",
            color="crimson", markersize=10, linewidth=2,
            markeredgecolor="darkred", markeredgewidth=1.2)
    for _, r in monthly.iterrows():
        ax.annotate(f"{r['gain_pct']:+.2f}%",
                    (r["month"], r["gain_pct"]),
                    xytext=(0, 10), textcoords="offset points",
                    ha="center", fontsize=10)
    ax.axhline(net_gain, color="gray", ls=":", lw=1.2,
               label=f"annual mean = {net_gain:+.3f}%")
    ax.axhline(0, color="k", lw=0.6)
    ax.set_ylabel("AEP net gain (%)", fontsize=12)
    ax.set_title(f"{region_name} -- 6x6 @ 7D, 2025 annual AEP gain "
                 f"(1h, GREEDY 1-{MAX_SPRAY} spray, T>=0degC)", fontsize=13)
    ax.legend(fontsize=11); ax.grid(alpha=0.3)

    ax = axes[1]
    w = 0.6
    ax.bar(monthly["month"], monthly["spray_h"], w,
           color="steelblue", edgecolor="k", linewidth=0.6,
           label="Actually spraying")
    ax.bar(monthly["month"], monthly["skip_h"], w,
           bottom=monthly["spray_h"],
           color="lightcoral", edgecolor="k", linewidth=0.6,
           label="Skipped (net < 0)")
    ax.bar(monthly["month"], monthly["frozen_h"], w,
           bottom=monthly["spray_h"] + monthly["skip_h"],
           color="lightcyan", edgecolor="k", linewidth=0.6,
           label="Frozen skipped (T < 0 degC)")
    ax.set_xlabel("Month", fontsize=12)
    ax.set_ylabel("Hours", fontsize=12)
    ax.set_title("Monthly hours: spray / net<0 skip / frozen skip",
                 fontsize=13)
    ax.set_xticks(range(1, 13)); ax.set_xticklabels(labels_m)
    ax.grid(alpha=0.3, axis="y"); ax.legend(fontsize=10)

    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "fig_monthly.png"),
                dpi=140, bbox_inches="tight")
    plt.close()

    # ---------- Figure 2 ----------
    fig, axes = plt.subplots(2, 2, figsize=(14, 11))

    ax = axes[0, 0]
    ax.hist(res["ws"], bins=40, color="steelblue",
            edgecolor="k", linewidth=0.4)
    ax.set_xlabel("WS (m/s)"); ax.set_ylabel("Count")
    ax.set_title("Wind speed distribution (all cases)")
    ax.grid(alpha=0.3, axis="y")

    ax = axes[0, 1]
    spray_res  = res[res["use_spray"]]
    skip_res   = res[(res["trigger"]) & (~res["use_spray"])]
    frozen_res = res[res["frozen_skip"]]
    mean_gain_spray = spray_res["gain_pct"].mean() if len(spray_res) else 0.0
    ax.hist(spray_res["gain_pct"], bins=40, color="crimson",
            edgecolor="k", linewidth=0.4)
    ax.set_xlabel("Per-block net gain (%)"); ax.set_ylabel("Count")
    ax.set_title(f"Gain dist. (spraying)  n={len(spray_res)}, "
                 f"mean={mean_gain_spray:+.2f}%")
    ax.grid(alpha=0.3, axis="y")

    ax = axes[1, 0]
    if len(spray_res):
        sc = ax.scatter(spray_res["ws"], spray_res["gain_pct"],
                        c=spray_res["f_evap"], cmap="viridis",
                        s=10, alpha=0.5, edgecolor="k", linewidth=0.1,
                        vmin=0.4, vmax=1.0)
        plt.colorbar(sc, ax=ax, label="$f_{evap}$", shrink=0.9)
    ax.set_xlabel("WS (m/s)"); ax.set_ylabel("Net gain (%)")
    ax.set_title("Gain vs WS (spraying)")
    ax.grid(alpha=0.3)

    ax = axes[1, 1]
    if len(spray_res):
        sc = ax.scatter(spray_res["T_C"], spray_res["RH"],
                        c=spray_res["f_evap"], cmap="viridis",
                        s=10, alpha=0.5, edgecolor="k", linewidth=0.1,
                        marker="o", vmin=0.0, vmax=1.0,
                        label=f"Spray (n={len(spray_res)})")
    if len(skip_res):
        ax.scatter(skip_res["T_C"], skip_res["RH"],
                   c="red", s=20, alpha=0.7, edgecolor="k",
                   linewidth=0.3, marker="x",
                   label=f"Net<0 (n={len(skip_res)})")
    if len(frozen_res):
        ax.scatter(frozen_res["T_C"], frozen_res["RH"],
                   c="blue", s=20, alpha=0.7, edgecolor="k",
                   linewidth=0.3, marker="s",
                   label=f"Frozen T<0 (n={len(frozen_res)})")
    ax.axvline(T_MIN_SPRAY, color="blue", ls="--", lw=1.2, alpha=0.7,
               label=f"T_min = {T_MIN_SPRAY}degC")
    ax.set_xlabel("T (degC)"); ax.set_ylabel("RH (%)")
    ax.set_title("RH vs T")
    if len(spray_res):
        plt.colorbar(sc, ax=ax, label="$f_{evap}$", shrink=0.9)
    ax.legend(fontsize=9, loc="upper left"); ax.grid(alpha=0.3)

    plt.suptitle(f"{region_name} -- 6x6 @ 7D (1h, full year) "
                 f"| net gain = {net_gain:+.3f}%", fontsize=14, y=1.0)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "fig_4panel.png"),
                dpi=140, bbox_inches="tight")
    plt.close()

    # ---------- Figure 3: Top-view contour (True FLORIS + Griddata) ----------
    if len(spray_res) == 0:
        print("No spraying block -- skip representative figure")
    else:
        # Select the block with maximum gain for a visually clear flow field
        rep = spray_res.loc[spray_res["gain_pct"].idxmax()]

        rep_wd = float(rep["wd"]); rep_ws = float(rep["ws"])
        rep_T  = float(rep["T_C"]); rep_RH = float(rep["RH"])
        rep_m  = float(rep["m_evap"]); rep_tilt = float(rep["tilt"])
        rep_vg = float(rep["vg"])
        rep_gain = float(rep["gain_pct"]); rep_f = float(rep["f_evap"])

        try:
            rep_spray_units = list(ast.literal_eval(rep["spray_units"]))
        except Exception:
            rep_spray_units = []
        upstream_idx = set(rep_spray_units)

        print(f"\nRepresentative block (Max Gain) for flow visualization:")
        print(f"  WD = {rep_wd:.1f} deg, WS = {rep_ws:.2f} m/s")
        print(f"  T = {rep_T:.1f} degC, RH = {rep_RH:.1f}%")
        print(f"  m_evap = {rep_m:.1f} kg/s, f_evap = {rep_f:.3f}")
        print(f"  tilt = {rep_tilt:.2f} deg, gain = {rep_gain:+.3f}%")
        print(f"  n_spray = {len(upstream_idx)}, spray_units = {sorted(upstream_idx)}")

        def get_floris_plane(wd, ws, is_spray):
            if not is_spray:
                td = make_turbine_def(0., 0., "_vis_base")
                tt = [td] * N_TURB
            else:
                spray_td = make_turbine_def(rep_tilt, rep_tilt, "_vis_spray")
                base_td  = make_turbine_def(0., 0., "_vis_base")
                tt = [base_td] * N_TURB
                for i in upstream_idx:
                    tt[i] = spray_td
            
            fm_vis = FlorisModel(YAML_PATH)
            fm_vis.set(layout_x=layout_x.tolist(), layout_y=layout_y.tolist(),
                       turbine_type=tt, reference_wind_height=hub_H,
                       wind_directions=[wd], wind_speeds=[ws],
                       turbulence_intensities=[TI_BASE], wind_shear=WIND_SHEAR)
            
            if is_spray:
                we0  = max(WE_BASE[0], we0_from_fevap(ws, rep_f))
                fm_vis.core.wake.velocity_model.wake_expansion_rates = [we0, WE1_SPRAY]
                fm_vis.core.wake.deflection_model.vertical_deflection_gain_D = float(rep_vg)
                fm_vis.core.wake.deflection_model.deflection_rate = float(DEFLECTION_RATE)
                
                ta = np.zeros((1, N_TURB))
                for i in upstream_idx:
                    ta[0, i] = rep_tilt
                fm_vis.core.farm.tilt_angles = ta.copy()
                fm_vis.core.farm.tilt_angles_sorted = ta.copy()
            
            fm_vis.run()
            plane = fm_vis.calculate_horizontal_plane(
                height=hub_H, 
                x_resolution=300, 
                y_resolution=300
            )
            return plane.df

        print("  Extracting true FLORIS flow planes (this may take a few seconds)...")
        df_base = get_floris_plane(rep_wd, rep_ws, is_spray=False)
        df_spray = get_floris_plane(rep_wd, rep_ws, is_spray=True)

        grid_x, grid_y = np.meshgrid(
            np.linspace(df_base['x1'].min(), df_base['x1'].max(), 300),
            np.linspace(df_base['x2'].min(), df_base['x2'].max(), 300)
        )

        U_base = griddata((df_base['x1'], df_base['x2']), df_base['u'], (grid_x, grid_y), method='linear')
        U_spray = griddata((df_spray['x1'], df_spray['x2']), df_spray['u'], (grid_x, grid_y), method='linear')
        dU = U_spray - U_base

        vmin_u = np.nanmin([np.nanmin(U_base), np.nanmin(U_spray)])
        vmax_u = np.nanmax([np.nanmax(U_base), np.nanmax(U_spray)])
        
        dU_max_abs = np.nanmax(np.abs(dU))
        DU_FIXED = max(0.2, np.ceil(dU_max_abs * 10) / 10) 
        
        fig, axes = plt.subplots(1, 3, figsize=(22, 8))

        def draw_layout_xy(ax):
            for i in range(N_TURB):
                c  = "red"   if i in upstream_idx else "black"
                ms = 12      if i in upstream_idx else 6
                ax.plot(layout_x[i], layout_y[i], "o",
                        color=c, markersize=ms,
                        markeredgecolor="white", markeredgewidth=1.0,
                        zorder=10)
            theta = math.radians(rep_wd)
            ux = -math.sin(theta); uy = -math.cos(theta)
            L = 1000.0
            xc = np.mean(grid_x); yc = np.max(grid_y) - 500
            ax.annotate("", xy=(xc + ux*L, yc + uy*L),
                        xytext=(xc, yc),
                        arrowprops=dict(arrowstyle="-|>", color="black",
                                        lw=2.5, mutation_scale=20),
                        zorder=15)
            ax.text(xc - ux*L*0.6, yc - uy*L*0.6, "WD",
                    fontsize=11, fontweight="bold",
                    ha="center", va="center", zorder=15)
            ax.set_aspect("equal")
            ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)")
            ax.set_xlim(grid_x.min(), grid_x.max())
            ax.set_ylim(grid_y.min(), grid_y.max())

        ax = axes[0]
        cf = ax.pcolormesh(grid_x, grid_y, U_base, cmap="RdBu_r",
                           vmin=vmin_u, vmax=vmax_u, shading="auto", rasterized=True)
        draw_layout_xy(ax)
        ax.set_title(f"(a) No spray  (z={hub_H:.0f} m)\nWD={rep_wd:.0f} deg, WS={rep_ws:.1f} m/s", fontsize=11)
        plt.colorbar(cf, ax=ax, label="$u$ (m/s)", shrink=0.85)

        ax = axes[1]
        cf = ax.pcolormesh(grid_x, grid_y, U_spray, cmap="RdBu_r",
                           vmin=vmin_u, vmax=vmax_u, shading="auto", rasterized=True)
        draw_layout_xy(ax)
        ax.set_title(f"(b) Spray (n={len(upstream_idx)})\ntilt={rep_tilt:.1f} deg, vg={rep_vg:.2f}, gain={rep_gain:+.2f}%", fontsize=11)
        plt.colorbar(cf, ax=ax, label="$u$ (m/s)", shrink=0.85)

        ax = axes[2]
        cf = ax.pcolormesh(grid_x, grid_y, dU, cmap="RdBu_r",
                           vmin=-DU_FIXED, vmax=DU_FIXED, shading="auto", rasterized=True)
        draw_layout_xy(ax)
        ax.set_title(r"(c) $\Delta u$ = Spray $-$ No spray" + f"\n(fixed $\\pm {DU_FIXED:.1f}$ m/s)", fontsize=11)
        plt.colorbar(cf, ax=ax, label=r"$\Delta u$ (m/s)", shrink=0.85, extend="both")

        plt.suptitle(
            f"{region_name} -- IEA 15MW 6x6 (7D) "
            f"hub-height top view (z={hub_H:.0f} m)  |  "
            f"rep block: WD={rep_wd:.0f} deg, WS={rep_ws:.2f} m/s, "
            f"T={rep_T:.1f} degC, RH={rep_RH:.1f}%, "
            f"n_spray={len(upstream_idx)}, gain={rep_gain:+.2f}%",
            fontsize=12, y=0.98)
        plt.tight_layout(rect=[0, 0, 1, 0.95])
        plt.savefig(os.path.join(OUT_DIR, "fig_representative_topview.png"),
                    dpi=140, bbox_inches="tight")
        plt.close()

    print(f"\nOutputs -> {OUT_DIR}")

    return {
        "region": region_name,
        "block_h": BLOCK_HOURS,
        "AEP_base_MWh": AEP_base,
        "AEP_net_MWh":  AEP_net,
        "net_gain_pct": net_gain,
        "gross_gain_pct": gross_gain,
        "E_total_kWh": E_total_kWh,
        "energy_pct": energy_pct,
        "CF_pct": CF,
        "spray_h": spray_hours,
        "trigger_h": trigger_hours,
        "frozen_h": frozen_hours,
        "skip_h": skip_hours,
        "avg_n_candidates": avg_cand,
        "avg_n_spray": avg_spray,
        "calls_per_trigger": call_ratio,
    }

# ============================================================
# Main Program
# ============================================================
if __name__ == "__main__":
    os.makedirs(OUT_ROOT, exist_ok=True)
    t_all = time.time()
    summary_rows = []
    for region in REGIONS:
        try:
            r = run_region(region)
            if r is not None:
                summary_rows.append(r)
        except Exception as e:
            print(f"\n!!! Region {region} failed: {e}", flush=True)

    if summary_rows:
        summ = pd.DataFrame(summary_rows)
        summ_path = os.path.join(OUT_ROOT, "_ALL_REGIONS_6x6_1h_summary.csv")
        summ.to_csv(summ_path, index=False)
        print("\n" + "=" * 90)
        print("ALL REGIONS -- 6x6 @ 7D, 1h, GREEDY, full year")
        print("=" * 90)
        with pd.option_context("display.width", 220,
                                "display.max_columns", 50):
            print(summ.to_string(index=False))
        print("=" * 90)
        print(f"Summary -> {summ_path}")

    print(f"\nTotal wall time: {(time.time()-t_all)/60:.1f} min")
    print("All regions done.")